import matplotlib.pyplot as plt 
# use this library to visualize the data, draw pictures

# use this function to make it easier to get the picture we want
def simulate_cattle_population(initial_population, fertility_rate, death_rate, extra_new_cows_per_year, time_duration): 
    # initialize variables
    years = []
    population_size = []
    population = 0
    year = 0

    while year <= time_duration:
        # treat the beginning year as a special case
        if year == 0: 
            population = population + initial_population 
        else:
            population = population * (1 + fertility_rate - death_rate) + extra_new_cows_per_year
        # gather all the relavant data into their own list
        population_size.append(population)
        years.append(year)
        year += 1

    print(years, population_size,len(population_size))

    # set list 'year' as x-axis
    xpoints = years 
    # set list 'population_size' as y-axis
    ypoints = population_size 

    # draw the picture
    plt.plot(xpoints, ypoints)
    plt.show()

# call this function
simulate_cattle_population(100, 0.4, 0.3, 5, 50) 