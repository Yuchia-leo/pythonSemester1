x = int(input('What should be the height of the triangle? '))

if x in range(1,10):
    s = ""  
    for i in range(x, 0, -1):
        for j in range(0, x):
            c = " " if j < x - i else str(i)
            s += c + " "
        s += "\n"

    print(s)

else:
    print('Please input a whole number from 1 to 9')
    
