import numpy as np
import matplotlib.pyplot as plt

def simulate_cattle_population(initial_population, fertility_rate, death_rate, extra_new_cows_per_year, time_duration):
    years = []
    population_size = []
    population = 0
    year = 0
    while year <= time_duration:
        if year == 0:
            population = population + initial_population
        else:
            population = population * (1 + fertility_rate - death_rate) + extra_new_cows_per_year
        population_size.append(population)
        years.append(year)
        year += 1

    print(years, population_size,len(population_size))

    xpoints = np.array(years)
    ypoints = np.array(population_size)

    plt.plot(xpoints, ypoints)
    plt.show()

simulate_cattle_population(100, 0.4, 0.3, 5, 50)