# use while loop to ask an input again if the user doesn't provide a valid input, until a valid input is provided
while True: 
    
    height = int(input('What should be the height of the triangle? '))
    if height in range(1,10):
        # use a string variable to hold the result so that printing can be done one time at the end 
        s = ""  
        
        # print (height - 1) spaces then print number i for i times to form a rectangle
        for i in range(height, 0, -1): 
            
            for j in range(0, height):
            
                c = " " if j < height - i else str(i) 
                s += c + " "
            s += "\n"

        print(s)
        #stop looping when the triangle is printed
        break
    else:
        #ask for a valid input
        print('Please input a whole number from 1 to 9')
