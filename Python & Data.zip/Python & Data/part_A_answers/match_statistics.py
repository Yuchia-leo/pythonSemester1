import math 
# import 'math' library to use mathematical matter---'infinity'

# open the file and divide data into split lines
with open('barca.txt','r') as barca_data:
    match_list = barca_data.read().splitlines()

#Home Matches
def number_of_home_matches_per_year(list):
    # initialize variables
    home_matches_2011 = 0
    home_matches_2012 = 0
    home_matches_2013 = 0
    home_matches_2014 = 0
    home_matches = []
    
    # calculate home matches in each year
    for i in list:
        if 'home' in i:
            if '/11,' in i:
                home_matches_2011 += 1
            
            if '/12,' in i: 
                home_matches_2012 += 1
            
            if '/13,' in i:
                home_matches_2013 += 1
            
            if '/14,' in i:
                home_matches_2014 += 1
  
    # add numbers of home matches in each year into a list        
    home_matches.append(home_matches_2011)
    home_matches.append(home_matches_2012)
    home_matches.append(home_matches_2013)
    home_matches.append(home_matches_2014)
   

    print(home_matches)


#Winning Streak
def longest_streak(list):
    # initialize variables
    win = 0
    streak = []

    for i in list:
    # calculate numbers of the streak
        if 'won' in i:
            win += 1

    # initialize streak when lost or draw
        elif  'lost' in i or 'draw' in i:
            streak.append(win)
            win = 0

    print(max(streak))


#Improvement
def biggest_improvement(list):
    # set this variable as negative infinity to make sure it is smaller than anyone
    biggest_improvement_score = -math.inf 
    
    # initialize this variable  
    biggest_improvement_date = None 
    for i in range(1, len(list)):
        prev_row = list[i - 1]
        curr_row = list[i]
        
        # split items with ','
        prev_row_items = prev_row.split(",")
        curr_row_items = curr_row.split(",")

        # calculate improvement score of each match
        improvement_score = int(curr_row_items[3]) - int(prev_row_items[3])
        
        # compare improvement score of each match with the biggest one
        if improvement_score > biggest_improvement_score:
            biggest_improvement_score = improvement_score
            biggest_improvement_date = curr_row_items[0]
        
    print('On', biggest_improvement_date, ', Barcelona made the biggest improvement by scoring', biggest_improvement_score, 'goals more than the last match.')

# call functions
number_of_home_matches_per_year(match_list)
longest_streak(match_list)
biggest_improvement(match_list)

# close the file
barca_data.close()



        
        
        
        
        
    


    
    
