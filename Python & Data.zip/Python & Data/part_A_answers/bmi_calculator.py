weight = input('what is your weight(kg)?  ' )
height = input('what is your height(m)?   ' )

# calculate BMI
BMI = float(weight) / pow(float(height), 2)

print('BMI value is', round(BMI,1))

# print results of different BMI
if BMI < 18.5:
   print('It falls within the Underweight range.')
elif BMI <25:
   print('It falls within the Healthy Weight range')
elif BMI <30:
   print('It falls within the Overweight range')
else:
   print('It falls within the Obese range')
   
