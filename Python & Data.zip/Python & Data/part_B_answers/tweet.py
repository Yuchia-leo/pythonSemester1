from sentiment_for_tweet import *
from matplotlib import pyplot as plt

#open file
with open('trump.txt', encoding='utf8') as tweet_file:
    tweets = tweet_file.read().splitlines()


#clean data
clean_tweets = []
for i in tweets:
    i = i[31:]
    clean_tweet = cleanup(i)
    clean_tweets.append(clean_tweet)


#put data with different sentiment score into their lists
neg_tweets_count = 0
pos_tweets_count = 0
neu_tweets_count = 0
for x in clean_tweets:
    y = sentiment_of_text(x)
    if y < 0:
        neg_tweets_count += 1
    elif y == 0:
        neu_tweets_count += 1
    elif y > 0:
        pos_tweets_count += 1

print(neg_tweets_count, neu_tweets_count, pos_tweets_count)

# print pie chart
labels = 'Negative','Neutral','Positive'
plt.pie([neg_tweets_count, neu_tweets_count, pos_tweets_count], labels=labels, colors= ['yellow','green','red'], autopct='%1.1f%%')
plt.show()
        


        

        





