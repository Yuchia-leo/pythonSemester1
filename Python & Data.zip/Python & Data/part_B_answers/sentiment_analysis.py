#load files
def load_words(filename):
    content = open(filename)
    lines = content.read().splitlines()
    content.close()
    return lines[35:]

def load_positive_words():
    return load_words('pos_words.txt')

def load_negative_words():
    return load_words('neg_words.txt')

pos_words = load_positive_words()
neg_words = load_negative_words()



#input words
word = input('Give me a text: ')


#clean word
def cleanup(word):
    for element in word:
        if element.isalpha() == False and element.isdigit() == False and element != '-' and element != '+' and element !=' ':
                word = word.replace(element,'')
    word = word.lower()
    word = word.split()
    
    return word


#calculate scores
def sentiment_of_text(text):
    sentiment_score = 0
    for items in text:
        if items in pos_words:
            sentiment_score += 1
        elif items in neg_words:
            sentiment_score -= 1
        else:
            sentiment_score += 0
        
    return sentiment_score


sentiment_score = sentiment_of_text(cleanup(word))


print('Sentiment score of the text is', sentiment_score)

#create a function to print attitude
def attitude(sentiment_score):
    if sentiment_score < 0:
        x = "It means that the writer has a negative attitude. :("
    elif sentiment_score == 0:
        x = "It means that the writer has a neutral attitude. :|"
    else:
        x = "It means that the writer has a positive attitude. :)"
    
    return x.strip()

print(attitude(sentiment_score))

